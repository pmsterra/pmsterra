from fastapi import FastAPI, Request
from pydantic import BaseModel

app = FastAPI()

class Message(BaseModel):
    user_input: str

@app.get("/")
def root():
    return {"message": "Agent is running!"}

@app.post("/chat")
def chat(msg: Message):
    user_message = msg.user_input
    response = generate_response(user_message)
    return {"response": response}

def generate_response(user_input: str) -> str:
    # A placeholder "agent" that gives canned responses
    if "hello" in user_input.lower():
        return "Hi there! How can I help you today?"
    elif "bye" in user_input.lower():
        return "Goodbye!"
    else:
        return f"You said: {user_input}"

